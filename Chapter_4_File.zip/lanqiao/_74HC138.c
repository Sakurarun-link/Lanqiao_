#include <STC15F2K60S2.H>
#include "_74HC138.H"

void _74HC138_init(unsigned char n){
	switch(n){
		case 4 : P2 = ( P2 & 0x1f ) | 0x80;break;
		case 5 : P2 = ( P2 & 0x1f ) | 0xa0;break;
		case 6 : P2 = ( P2 & 0x1f ) | 0xc0;break;
		case 7 : P2 = ( P2 & 0x1f ) | 0xe0;break;
	}
	
	P2 &= 0x1f;
}

void _74HC138_init_all(void){
	P0 = 0xFF;
	_74HC138_init(4);
	P0 = 0x00;
	_74HC138_init(5);
	_74HC138_init(6);
	_74HC138_init(7); 


}

