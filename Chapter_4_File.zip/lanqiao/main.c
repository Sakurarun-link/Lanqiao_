//main.c
#include <STC15F2K60S2.H>
#include "_74HC138.h"
#include "nixie.h"



void Timer0_Init(void)		//1??@12.000MHz
{
	AUXR &= 0x7F;			//?????12T??
	TMOD &= 0xF0;			//???????
	TL0 = 0x18;				//???????
	TH0 = 0xFC;				//???????
	TF0 = 0;				//??TF0??
	TR0 = 1;				//???0????
	ET0 = 1;	
  EA = 1;	//?????0??
}


void Timer0_Isr(void) interrupt 1
{
	static unsigned char count1 = 0;
	count1++;
	if(count1 >= 2)
	{
	nixie_loop();
	count1 = 0;
	}
}

void main()
{
_74HC138_init_all();
Timer0_Init();
while(1)
{
set_nixie_display(1,2);

}
}