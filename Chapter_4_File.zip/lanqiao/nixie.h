#ifndef _NIXIE_H_
#define _NIXIE_H_


void nixie(unsigned char Location, display);
void nixie_loop();
void set_nixie_display(unsigned char Location, display);



#endif