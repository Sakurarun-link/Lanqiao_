#include "LED.h"
#include <STC15F2K60S2.H>
#include "_74HC138.H"

void LED(unsigned char Location){
P0 = ~(0x01 << (Location - 1));
	_74HC138_init(4);
}