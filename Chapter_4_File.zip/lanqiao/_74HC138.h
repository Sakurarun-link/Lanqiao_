//SM74HC138.h
#ifndef __74HC138_H_
#define __74HC138_H_

void _74HC138_init(unsigned char n);
void _74HC138_init_all(void);

#endif

